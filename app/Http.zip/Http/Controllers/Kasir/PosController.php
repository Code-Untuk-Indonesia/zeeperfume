<?php

namespace App\Http\Controllers\Kasir;

use App\Http\Controllers\Controller;
use App\Models\BranchStock;
use App\Models\Category;
use App\Models\Member;
use App\Models\Product;
use App\Models\StockHistory;
use App\Models\Transaction;
use App\Models\TransactionDetail;
use App\Support\BranchOperatingHours;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class PosController extends Controller
{
    /**
     * Menampilkan halaman transaksi (POS) Kasir
     */
    public function index(BranchOperatingHours $operatingHours)
    {
        // Ambil ID Cabang dari Kasir yang sedang login (Fallback ke 1 jika null)
        $cabangId = auth()->user()->cabang_id ?? 1;

        // Cek apakah toko buka atau tutup saat halaman dimuat
        $closedMessage = $operatingHours->closedMessage($cabangId);

        // Ambil semua kategori untuk tombol filter
        $categories = Category::all();

        // Ambil produk (yang fisiknya ada), beserta varian dan stok di cabang kasir ini
        $products = Product::with(['category', 'variants' => function ($query) use ($cabangId) {
            $query->with(['branchStocks' => function ($stockQuery) use ($cabangId) {
                $stockQuery->where('cabang_id', $cabangId);
            }]);
        }])
            ->where('tipe_stok', 'ada_stok')
            ->get();

        // Kirimkan $closedMessage ke View
        return view('kasir.pos.index', compact('categories', 'products', 'closedMessage'));
    }

    /**
     * Memproses dan menyimpan transaksi ke Database
     */
    public function store(Request $request, BranchOperatingHours $operatingHours)
    {
        $cabangId = auth()->user()->cabang_id ?? 1;

        // Proteksi Backend: Tetap cegah transaksi jika di-bypass
        $closedMessage = $operatingHours->closedMessage($cabangId);
        if ($closedMessage !== null) {
            return response()->json([
                'success' => false,
                'message' => $closedMessage,
            ], 403);
        }

        $validated = $request->validate([
            'cart'          => 'required|array',
            'metode_bayar'  => ['required', Rule::in(['cash', 'qris', 'transfer', 'cash_tempo'])],
            'nominal_bayar' => 'required|numeric|min:0',
            'subtotal'      => 'required|numeric', // Subtotal dasar (sebelum diskon global)
            'discount'      => 'required|numeric', // Diskon global / tambahan
            'total'         => 'required|numeric', // Total akhir
            'member_id'     => [
                'nullable',
                'integer',
                Rule::exists('members', 'id')->whereNull('deleted_at'),
            ],
            'is_point_used' => 'sometimes|boolean',
            'used_points'   => 'sometimes|integer|min:0',
            'diskon_persen' => 'sometimes|numeric|min:0|max:100',
            'cash_tempo'    => 'nullable|required_if:metode_bayar,cash_tempo|array',
            'cash_tempo.tanggal_jatuh_tempo' => 'required_if:metode_bayar,cash_tempo|date|after_or_equal:today',
            'cash_tempo.catatan_penagihan' => 'nullable|string|max:1000',
        ]);

        $metodeBayar = strtolower($validated['metode_bayar']);
        $totalBelanja = (float) $validated['total'];
        $nominalBayar = (float) $validated['nominal_bayar'];

        if ($metodeBayar === 'cash' && $nominalBayar < $totalBelanja) {
            throw ValidationException::withMessages([
                'nominal_bayar' => 'Nominal uang tunai kurang dari total tagihan.',
            ]);
        }

        if ($metodeBayar === 'cash_tempo' && $nominalBayar > $totalBelanja) {
            throw ValidationException::withMessages([
                'nominal_bayar' => 'Pembayaran awal cash tempo tidak boleh melebihi total tagihan.',
            ]);
        }

        DB::beginTransaction();
        try {
            $kasirId  = auth()->id() ?? 3; // Fallback ke kasir ID 3 jika testing
            $waktu    = Carbon::now();

            // 1. Generate Nomor Nota (Format: INV-YYYYMMDD-XXXX)
            $lastTrx = Transaction::whereDate('tanggal_waktu', $waktu->toDateString())->count();
            $nomorNota = 'INV-' . $waktu->format('Ymd') . '-' . str_pad($lastTrx + 1, 4, '0', STR_PAD_LEFT);

            // Hitung kembalian (hanya jika tunai)
            $kembalian = $metodeBayar === 'cash'
                ? max(0, $nominalBayar - $totalBelanja)
                : 0;

            // Jika metode non-cash, nominal bayar dianggap pas (sama dengan total tagihan)
            $nominalBayarAsli = ! in_array($metodeBayar, ['cash', 'cash_tempo'], true)
                ? $totalBelanja
                : $nominalBayar;

            // 2. Buat Data Transaksi Induk
            $transaction = Transaction::create([
                'kasir_id'         => $kasirId,
                'member_id'        => $validated['member_id'] ?? null,
                'nomor_nota'       => $nomorNota,
                'tanggal_waktu'    => $waktu,
                'subtotal'         => $validated['subtotal'], // Subtotal sebelum diskon global
                'diskon_persen'    => $validated['diskon_persen'] ?? 0,
                'diskon_nominal'   => $validated['discount'], // Total diskon tambahan / poin
                'deskripsi_diskon' => ($validated['is_point_used'] ?? false) ? 'Tukar Poin Member' : ($validated['discount'] > 0 ? 'Diskon Manual/Persen' : null),
                'total_belanja'    => $totalBelanja,
                'nominal_bayar'    => $nominalBayarAsli,
                'kembalian'        => $kembalian,
                'metode_bayar'     => $metodeBayar,
                'cabang_id'        => $cabangId,
            ]);

            // 3. Looping Keranjang untuk Detail Transaksi, Potong Stok, dan History
            foreach ($validated['cart'] as $item) {
                $qtyOrMl = $item['unit'] === 'ml' ? $item['ml'] : $item['qty'];
                $hargaSatuan = $item['unit'] === 'ml' ? $item['pricePerMl'] : $item['price'];

                // Hitung Harga Dasar Item
                $subtotalItemDasar = $item['unit'] === 'ml' ? $item['price'] : ($hargaSatuan * $item['qty']);

                // Potong dengan diskon per item (jika ada input dari kasir)
                $diskonItem = $item['itemDiscount'] ?? 0;
                $subtotalFinalItem = max(0, $subtotalItemDasar - $diskonItem);

                // Insert Detail Transaksi
                $discountType = $item['discountType'] ?? 'rupiah';
                $discountInput = (float) ($item['discountInput'] ?? 0);

                TransactionDetail::create([
                    'transaksi_id'  => $transaction->id,
                    'varian_id'     => $item['variantId'],
                    'qty'           => $qtyOrMl,
                    'harga_satuan'  => $hargaSatuan,
                    'diskon_persen' => $discountType === 'percent' ? $discountInput : 0,
                    'diskon_satuan' => $diskonItem,
                    'catatan_diskon' => $diskonItem > 0 ? 'Diskon item' : null,
                    'subtotal'      => $subtotalFinalItem,
                ]);

                // Kurangi Stok Cabang
                $stock = BranchStock::where('cabang_id', $cabangId)
                    ->where('varian_id', $item['variantId'])
                    ->first();
                if ($stock) {
                    $stock->decrement('stok', $qtyOrMl);
                }

                // Catat di Stock History
                StockHistory::create([
                    'cabang_id'     => $cabangId,
                    'varian_id'     => $item['variantId'],
                    'user_id'       => $kasirId,
                    'transaksi_id'  => $transaction->id,
                    'jenis_riwayat' => 'penjualan',
                    'qty'           => -$qtyOrMl, // Minus karena keluar
                    'keterangan'    => 'Penjualan ' . $item['name'] . ($item['unit'] === 'ml' ? " ($qtyOrMl ml)" : ''),
                    'waktu'         => $waktu,
                ]);
            }

            // 4. Catatan Piutang jika Metode Kasbon/Tempo
            if ($metodeBayar === 'cash_tempo') {
                $sisaPiutang = max(0, $totalBelanja - $nominalBayar);
                $now = Carbon::now();

                DB::table('cash_tempo')->insert([
                    'transaksi_id'        => $transaction->id,
                    'tanggal_jatuh_tempo' => $validated['cash_tempo']['tanggal_jatuh_tempo'],
                    'jumlah_piutang'      => $totalBelanja,
                    'sisa_piutang'        => $sisaPiutang,
                    'status_tempo'        => $sisaPiutang > 0 ? 'belum_lunas' : 'lunas',
                    'status_verifikasi'   => 'menunggu',
                    'catatan_penagihan'   => $validated['cash_tempo']['catatan_penagihan'] ?? null,
                    'created_at'          => $now,
                    'updated_at'          => $now,
                ]);
            }

            // 5. Potong Poin Member (Jika menggunakan opsi Tukar Poin)
            if (($validated['member_id'] ?? null) && ($validated['is_point_used'] ?? false) && ($validated['used_points'] ?? 0) > 0) {
                $member = Member::find($validated['member_id']);
                if ($member) {
                    $member->decrement('poin', $validated['used_points']);
                }
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'transaction_id' => $transaction->id,
                'redirect_url' => url('kasir/pos/success?trx_id=' . $transaction->id),
                'receipt_url' => route('kasir.pos.receipt', $transaction->id)
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    /**
     * Mencari Member berdasarkan No HP via AJAX
     */
    public function searchMember(Request $request)
    {
        $phone = preg_replace('/[^0-9]/', '', $request->phone);

        $member = \App\Models\Member::where('no_telp', $phone)
            ->orWhere('no_telp', 'like', "%{$phone}%")
            ->first();

        if (!$member) {
            return response()->json(['success' => true, 'found' => false]);
        }

        return response()->json([
            'success' => true,
            'found'   => true,
            'member'  => [
                'id'     => $member->id,
                'name'   => $member->nama,
                'points' => $member->poin ?? 0,
            ]
        ]);
    }

    /**
     * Menampilkan form tambah member dari kasir
     */
    public function createMember()
    {
        return view('kasir.member.create');
    }

    /**
     * Memproses penyimpanan data member baru
     */
    public function storeMember(Request $request)
    {
        $request->validate([
            'name'  => 'required|string|max:255',
            'phone' => 'required|string|max:20|unique:members,no_telp',
        ], [
            'phone.unique' => 'Nomor HP ini sudah terdaftar sebagai member.',
        ]);

        $lastMember = Member::latest('id')->first();
        $nextId = $lastMember ? $lastMember->id + 1 : 1;
        $kodeMember = 'MEM-' . date('Ymd') . '-' . str_pad($nextId, 3, '0', STR_PAD_LEFT);

        Member::create([
            'kode_member'       => $kodeMember,
            'nama'              => $request->name,
            'no_telp'           => $request->phone,
            'poin'              => 0,
            'tanggal_bergabung' => Carbon::now()->toDateString(),
            'status'            => 'aktif'
        ]);

        return redirect()->route('kasir.pos')->with('success', 'Member baru berhasil didaftarkan!');
    }

    public function history(Request $request)
    {
        $kasirId = auth()->id() ?? 3;
        $today = Carbon::today();

        $baseQuery = Transaction::with('member')
            ->where('kasir_id', $kasirId)
            ->whereDate('tanggal_waktu', $today);

        $totalPendapatan = (clone $baseQuery)->sum('total_belanja');
        $totalTransaksi = (clone $baseQuery)->count();
        $tunai = (clone $baseQuery)->where('metode_bayar', 'cash')->sum('total_belanja');
        $qrisTransfer = (clone $baseQuery)->whereIn('metode_bayar', ['qris', 'transfer'])->sum('total_belanja');
        $tempo = (clone $baseQuery)->whereIn('metode_bayar', ['tempo', 'cash_tempo'])->sum('total_belanja');

        $query = clone $baseQuery;

        if ($request->filled('search')) {
            $query->where('nomor_nota', 'like', '%' . $request->search . '%');
        }

        if ($request->filled('metode')) {
            if ($request->metode === 'qris_transfer') {
                $query->whereIn('metode_bayar', ['qris', 'transfer']);
            } elseif ($request->metode === 'tempo') {
                $query->whereIn('metode_bayar', ['tempo', 'cash_tempo']);
            } elseif ($request->metode !== 'semua') {
                $query->where('metode_bayar', $request->metode);
            }
        }

        $transactions = $query->orderBy('tanggal_waktu', 'desc')->paginate(10);

        return view('kasir.pos.history', compact(
            'transactions',
            'totalPendapatan',
            'totalTransaksi',
            'tunai',
            'qrisTransfer',
            'tempo',
            'today'
        ));
    }

    public function detail(int $transactionId)
    {
        $kasirId = auth()->id() ?? 3;

        $transaction = DB::table('transactions')
            ->where('transactions.id', $transactionId)
            ->where('transactions.kasir_id', $kasirId)
            ->first();

        if ($transaction === null) {
            return response()->json([
                'success' => false,
                'message' => 'Transaksi tidak ditemukan atau bukan milik kasir ini.',
            ], 404);
        }

        $transaction->member = $transaction->member_id === null
            ? null
            : DB::table('members')
            ->where('id', $transaction->member_id)
            ->whereNull('deleted_at')
            ->first(['id', 'kode_member', 'nama', 'no_telp']);

        $transaction->cash_tempo = DB::table('cash_tempo')
            ->where('transaksi_id', $transaction->id)
            ->first();

        $transaction->shipment = DB::table('shipments')
            ->where('transaksi_id', $transaction->id)
            ->first();

        $transaction->details = DB::table('transaction_details')
            ->leftJoin('produk_varian', 'produk_varian.id', '=', 'transaction_details.varian_id')
            ->leftJoin('products', 'products.id', '=', 'produk_varian.produk_id')
            ->where('transaction_details.transaksi_id', $transaction->id)
            ->orderBy('transaction_details.id')
            ->select([
                'transaction_details.id',
                'transaction_details.varian_id',
                'transaction_details.qty',
                'transaction_details.harga_satuan',
                'transaction_details.diskon_persen',
                'transaction_details.diskon_satuan',
                'transaction_details.catatan_diskon',
                'transaction_details.subtotal',
                'produk_varian.sku',
                'produk_varian.nama_varian',
                'produk_varian.satuan',
                'products.nama_produk',
            ])
            ->get();

        return response()->json([
            'success' => true,
            'data' => $transaction,
        ]);
    }

    public function success(Request $request)
    {
        $trxId = $request->query('trx_id');

        if (!$trxId) {
            return redirect()->route('kasir.pos');
        }

        $kasirId = auth()->id() ?? 3;
        $transaction = Transaction::with([
            'member',
            'cashier',
            'branch',
            'details.variant.product',
            'cashTempo',
            'shipment',
        ])->where('kasir_id', $kasirId)->findOrFail($trxId);

        return view('kasir.pos.success', compact('transaction'));
    }

    public function storeAjax(Request $request)
    {
        $request->validate([
            'nama_kategori' => 'required|string|max:255|unique:categories,nama_kategori',
        ]);

        try {
            $category = Category::create([
                'nama_kategori' => $request->nama_kategori,
            ]);

            return response()->json([
                'success' => true,
                'category' => $category,
                'message' => 'Kategori berhasil ditambahkan!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Gagal menambahkan kategori: ' . $e->getMessage()
            ], 500);
        }
    }

    public function receipt($trx_id)
    {
        $transaction = Transaction::with([
            'member',
            'cashier',
            'branch',
            'details.variant.product',
            'cashTempo',
        ])->findOrFail($trx_id);

        return view('kasir.pos.receipt', compact('transaction'));
    }
}
